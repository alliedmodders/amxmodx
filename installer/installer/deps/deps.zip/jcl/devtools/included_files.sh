#!/bin/sh
#
# shell script to create templates

cp ../source/include/jcl.template.inc ../source/include/jclc6.inc
cp ../source/include/jcl.template.inc ../source/include/jcld6.inc
cp ../source/include/jcl.template.inc ../source/include/jcld7.inc
cp ../source/include/jcl.template.inc ../source/include/jclcs1.inc
cp ../source/include/jcl.template.inc ../source/include/jcld8.inc
cp ../source/include/jcl.template.inc ../source/include/jcld9.inc
cp ../source/include/jcl.template.inc ../source/include/jcld10.inc
cp ../source/include/jcl.template.inc ../source/include/jcld11.inc
cp ../source/include/jcl.template.inc ../source/include/jcld12.inc
cp ../source/include/jcl.template.inc ../source/include/jcld14.inc
cp ../source/include/jcl.template.inc ../source/include/jcld15.inc
cp ../source/include/jcl.template.inc ../source/include/jcld16win32.inc
cp ../source/include/jcl.template.inc ../source/include/jcld16win64.inc

cp ../source/include/jcl.template.inc ../source/include/jclfpc.inc
