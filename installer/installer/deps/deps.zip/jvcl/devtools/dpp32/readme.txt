This directory contains a copy of the Delphi Preprocessor from
http://www.sourceforge.net/projects/dpp32 (CVS: 2004-09-13)
