#ifndef TRI_H
#define TRI_H

#include "particleman.h"

extern IParticleMan *g_pParticleMan;






#endif //TRI_H